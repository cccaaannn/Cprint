from distutils.core import setup

setup(
    name='extprint',
    version='0.6',
    packages=['extprint',],
    license='mit'
)
